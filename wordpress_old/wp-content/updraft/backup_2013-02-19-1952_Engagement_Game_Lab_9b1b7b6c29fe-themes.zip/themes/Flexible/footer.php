			</div> 	<!-- end #main-area -->
		
		<footer id="main_footer" class="clearfix">
			<p id="copyright"><?php printf( __('Designed by %s | Powered by %s', 'Flexible'), '<a href="http://www.elegantthemes.com" title="Premium WordPress Themes">Elegant Themes</a>', '<a href="http://www.wordpress.org">WordPress</a>' ); ?></p>
		</footer> <!-- end #main_footer -->
	</div> <!-- end #container -->

	<?php wp_footer(); ?>
</body>
</html>