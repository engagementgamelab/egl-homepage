	<div class="sidebar">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar Widget') ) : ?>
		<?php endif; ?>
	</div>

