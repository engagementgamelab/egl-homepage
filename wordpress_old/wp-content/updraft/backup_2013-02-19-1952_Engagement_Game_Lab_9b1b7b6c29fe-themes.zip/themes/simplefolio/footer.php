			</div>

		</div>

		<div id="footer">

			<div class="footernav">

				<img src="http://engagementgamelab.org/wp-content/uploads/2012/09/EGLSupportFooter-1.png" /> 

			</div>

			<div class="copyright">
        

				&copy; 2012 <?php bloginfo('name'); ?>. <br />
An applied research lab at <a href="http://www.emerson.edu/" target="_blank"> Emerson College </a>.<br />
                <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/3.0/"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-nd/3.0/80x15.png" /></a><br />This <span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/InteractiveResource" rel="dct:type">work</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/3.0/">Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License</a>.

			</div>

		</div>

	</div>

	<script type="text/javascript"> Cufon.now(); </script>

	

	<?php wp_footer(); ?>

</body>

</html>