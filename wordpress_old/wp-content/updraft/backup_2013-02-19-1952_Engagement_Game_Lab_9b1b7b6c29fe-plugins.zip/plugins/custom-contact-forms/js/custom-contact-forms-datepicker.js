// JavaScript Document
$m = jQuery.noConflict();
$m(document).ready(function(){
	$m(".ccf-datepicker").datepicker();
});