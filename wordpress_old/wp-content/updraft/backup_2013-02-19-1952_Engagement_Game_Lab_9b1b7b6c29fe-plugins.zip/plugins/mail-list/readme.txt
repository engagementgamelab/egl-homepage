=== Mail List ===
Contributors: danycode
Tags: mail list,mail,list,mailing list,mailing,subscription,subscriptions,marketing,email marketing,create newsletter,newsletter,free newsletter,email,email list,send newsletter,newsletter administrator,import newsletter,import,export,export newsletter,csv,csv import,csv export,newsletter free,send email,send mail,mail archive,newsletters,send newsletters
Donate link: http://www.danycode.com/mail-list/
License: GPLv2 or later
Requires at least: 2.8
Tested up to: 3.4
Stable tag: 1.10

Collect users email address with an awesome fully customizable form implemented with ajax, write and send newsletters, manage your mailing list.

== Description ==

Collect users email address with an awesome fully customizable form implemented with ajax, write and send newsletters, manage your mailing list.

For more information, check out <a href="http://www.danycode.com/mail-list/">Mail List</a>

Plugin Features:

- Collect email address with a form in the front end of the website
- Write newsletters in the back end with TinyMce
- CSV import and export
- Manage you mailing list
- Easy to use
- After the form submission a cookie named maillistcookie prevent to see again the form (delete this cookie to see again the form)

== Installation ==

1. Upload the Mail List plugin to your blog and activate it. 
2. Customize the plugin through: Mail List -> Options
3. Send the newsletters through: Mail List -> Send

== Screenshots ==

1. Front End Form.
